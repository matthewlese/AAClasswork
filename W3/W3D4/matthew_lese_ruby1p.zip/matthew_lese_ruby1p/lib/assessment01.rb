class Array
  # Write an `Array#my_inject` method. If my_inject receives no argument, then
  # use the first element of the array as the default accumulator.
  # **Do NOT use the built-in `Array#inject` or `Array#reduce` methods in your 
  # implementation.**
  require "byebug"

  def my_inject(accumulator = nil, &prc)
    if accumulator == nil
      accumulator = self[0]
      # (1...self.length).each do |ele|
      #   accumulator = prc.call(ele)
      # end
      accumulator
    else #given an argument
      acc = accumulator
      self.each do |ele|
        acc = prc.call(ele)
      end
      acc
    end
  end
end

# Define a method `primes(num)` that returns an array of the first "num" primes.
# You may wish to use an `is_prime?` helper method.

def is_prime?(num)
  (2...num).each do |fac|
    return false if num % fac == 0
  end
  true
end

def primes(num)
  primes = []
  i = 2
  while primes.size < num
    primes << i if is_prime?(i)
    i += 1
  end
  primes
end

# Write a recursive method that returns the first "num" factorial numbers.
# Note that the 1st factorial number is 0!, which equals 1. The 2nd factorial
# is 1!, the 3rd factorial is 2!, etc.

def factorials_rec(num)  #say we want first 3 i.e. num = 3
  factorials = [1, 1] #base cases
  return factorials[0...num] if num <= 2
  temp = factorials_rec(num - 1)
  temp + [((num - 1) * temp[-1])] #factorials_rec(2) = [1,1] ... + ((3-1) * [1,1][-1])

  factorials[0...num]
end

class Array
  # Write an `Array#dups` method that will return a hash containing the indices 
  # of all duplicate elements. The keys are the duplicate elements; the values 
  # are arrays of their indices in ascending order, e.g.
  # [1, 3, 4, 3, 0, 3, 0].dups => { 3 => [1, 3, 5], 0 => [4, 6] }

  def dups
    dupes = Hash.new()
    self.each do |ele|
      if self.count(ele) > 1
        indices = []
        self.each.with_index do |ele2, idx|
          indices << idx if ele2 == ele
        end
        dupes[ele] = indices
      end
    end
    dupes
  end
end

class String
  # Write a `String#symmetric_substrings` method that returns an array of 
  # substrings that are palindromes, e.g. "cool".symmetric_substrings => ["oo"]
  # Only include substrings of length > 1.
  def get_substrings
    substrings = []
    self.each_char.with_index do |char, i|
      (i...self.length).each { |end_idx| substrings << self[i..end_idx] }
    end
    substrings.select {|substring| substring.length > 1 }
  end

  def symmetric_substrings
    self.get_substrings.select do |substring|
      substring == substring.reverse
    end
  end
end

class Array
  # Write an `Array#merge_sort` method; it should not modify the original array.
  # **Do NOT use the built in `Array#sort` or `Array#sort_by` methods in your 
  # implementation.**
  
  def merge_sort(&prc)
    return [] if self.empty?
    return self if self.size == 1
  end

  private
  def self.merge(left, right, &prc)
  end
end
