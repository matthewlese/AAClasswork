class Array
  require "byebug"

  def my_each(&prc) #takes in a block
    i = 0
    while i < self.length
      prc.call(self[i])
      i += 1
    end
    self
  end

  def my_select(&prc)
    new_arr = []
      self.my_each do |el|
        new_arr << el if prc.call(el)
      end
    new_arr
  end

  def my_reject(&prc)
    new_arr = []
    self.my_each do |el|
      new_arr << el if !prc.call(el)
    end
    new_arr
  end

  def my_any?(&prc)
    self.my_each do |ele|
      return true if prc.call(ele)
    end
    false
  end

  def my_all?(&prc)
    self.my_each do |ele|
      return false if !prc.call(ele)
    end
    true
  end

  def my_flatten
    # debugger
    # return self if !self.is_a? Array
    # return [] if self.empty? 
    # [self[0]].my_flatten + self[1..-1].my_flatten
    new_arr = []
    self.my_each do |el|
      if !el.is_a?(Array)
        new_arr << el
      else
        new_arr += el.my_flatten
      end
    end
    new_arr
  end

  def my_zip(*args)
    new_arr = []
    self.my_each do |el|
      new_sub = [el] 
       i = self.index(el)
       args.my_each do |arg|
        new_sub << arg[i]
       end
      new_arr << new_sub
    end
    new_arr
  end

  def one_rotation
    new_arr = self[1..-1]
    new_arr << self.shift
  end

  def my_rotate(n=1)
    new_arr = self
    if n >= 1
      debugger
      n.times do
        new_arr = new_arr.one_rotation
      end
    else

    end
    new_arr
  end
end

a = [ "a", "b", "c", "d" ]
# p a.my_rotate         #=> ["b", "c", "d", "a"]
p a.my_rotate(2)      #=> ["c", "d", "a", "b"]
a.my_rotate(-3)     #=> ["b", "c", "d", "a"]
a.my_rotate(15)     #=> ["d", "a", "b", "c"]